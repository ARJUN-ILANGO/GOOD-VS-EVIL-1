var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["63b9e8e5-b64b-4b61-9771-ad34fb71f808","8737159e-5e1b-460f-8f45-6c67e0d8e2c4","720b6bb2-6444-48a9-ab03-0e613dcdf185","408dd599-0952-4565-b4b0-a167257f6046","62356b09-98fe-48a5-9c91-d320c0a39259","ade0e8d5-6ccb-4290-a4f7-1a0e5b9fbf1b","937275ba-1ff2-4d16-89cc-1f79375f4b04","3035aebe-362f-4892-8963-254a070b3f5d","bfd3fbf1-c50f-44e9-be56-a38453094c66","0076ca5f-aefc-4e0e-9a91-67bd02abb62d","f9e460b4-89eb-4a0a-9881-72b906d15a5a","200fcaf8-c55b-4ca3-bdec-a2e5afa814e7","be051262-d38e-4ec8-b0ac-5048d160c5dc","3b84c9b0-9798-4f36-ba42-21e363e4bd0a","0d5464ce-d933-46c4-aed2-657b4d1dbf1a","fb01deab-2e69-461e-a2b2-0376c722badf","9710c498-868c-4e1c-bb19-a4aeadd84930","289f17ca-c3c0-4482-b150-1672c9a43644","51109ae5-9a8a-4ca9-bf60-4bf18af27e1e","43b626de-e5d4-417d-ba27-0f25c905530c","2112346e-2580-4e0c-8472-ab0ff8acf246","8e4ccc0b-3540-4b96-a012-db26f30a1300","92d806d5-bd31-4f9c-9b6c-030766b0b886","4c96ead6-93d6-4ddc-b3bb-3828aba59e4c","de495cfd-653e-4801-850e-ab037ca60e23","3601afcf-9a96-47f2-a95e-ef66d0064cbd","17da732d-c1a6-4efa-a291-8fb20f9c53df","87331e83-0313-425c-bba3-0998395f9a2a"],"propsByKey":{"63b9e8e5-b64b-4b61-9771-ad34fb71f808":{"name":"Spiderman","sourceUrl":null,"frameSize":{"x":101,"y":116},"frameCount":3,"looping":true,"frameDelay":4,"version":"VmBqpDyKekYSSiU1sT14cDlOdpMk5Y0O","loadedFromSource":true,"saved":true,"sourceSize":{"x":202,"y":232},"rootRelativePath":"assets/63b9e8e5-b64b-4b61-9771-ad34fb71f808.png"},"8737159e-5e1b-460f-8f45-6c67e0d8e2c4":{"name":"coin_gold_1","sourceUrl":"assets/api/v1/animation-library/gamelab/TdRK.69bNZJmZSrrEjfa3Q83ABwRkj75/category_gameplay/coin_gold.png","frameSize":{"x":61,"y":61},"frameCount":1,"looping":true,"frameDelay":2,"version":"TdRK.69bNZJmZSrrEjfa3Q83ABwRkj75","loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":61},"rootRelativePath":"assets/api/v1/animation-library/gamelab/TdRK.69bNZJmZSrrEjfa3Q83ABwRkj75/category_gameplay/coin_gold.png"},"720b6bb2-6444-48a9-ab03-0e613dcdf185":{"name":"coin_silver_1","sourceUrl":"assets/api/v1/animation-library/gamelab/OcRvbgIR3zbB.MSS_TJVmCNwaJDxEZa2/category_gameplay/coin_silver.png","frameSize":{"x":61,"y":61},"frameCount":1,"looping":true,"frameDelay":2,"version":"OcRvbgIR3zbB.MSS_TJVmCNwaJDxEZa2","loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":61},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OcRvbgIR3zbB.MSS_TJVmCNwaJDxEZa2/category_gameplay/coin_silver.png"},"408dd599-0952-4565-b4b0-a167257f6046":{"name":"coin_bronze_1","sourceUrl":null,"frameSize":{"x":60,"y":61},"frameCount":4,"looping":true,"frameDelay":12,"version":"gIix5.p8XeaB.i8iOVfBl89NMDYL1.Bj","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":122},"rootRelativePath":"assets/408dd599-0952-4565-b4b0-a167257f6046.png"},"62356b09-98fe-48a5-9c91-d320c0a39259":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"L.BxsCMXquhehwTJ_GFSrXkwkrb9xtfQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/62356b09-98fe-48a5-9c91-d320c0a39259.png"},"ade0e8d5-6ccb-4290-a4f7-1a0e5b9fbf1b":{"name":"animation_2","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"k.MsyLJlTx6ANs6nDzREUD9QyYC9Wpa_","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/ade0e8d5-6ccb-4290-a4f7-1a0e5b9fbf1b.png"},"937275ba-1ff2-4d16-89cc-1f79375f4b04":{"name":"spring_1","sourceUrl":null,"frameSize":{"x":147,"y":112},"frameCount":1,"looping":true,"frameDelay":12,"version":"2qvrBrM9LcjahyXDssmj.hY1QpfOgmNX","loadedFromSource":true,"saved":true,"sourceSize":{"x":147,"y":112},"rootRelativePath":"assets/937275ba-1ff2-4d16-89cc-1f79375f4b04.png"},"3035aebe-362f-4892-8963-254a070b3f5d":{"name":"spring_in_out_1","sourceUrl":null,"frameSize":{"x":147,"y":112},"frameCount":6,"looping":false,"frameDelay":4,"version":"3LOaFsSpHptMAXaQmXZSzXTBbhNgdoII","loadedFromSource":true,"saved":true,"sourceSize":{"x":294,"y":336},"rootRelativePath":"assets/3035aebe-362f-4892-8963-254a070b3f5d.png"},"bfd3fbf1-c50f-44e9-be56-a38453094c66":{"name":"flatDark41_1","sourceUrl":"assets/api/v1/animation-library/gamelab/3Tm5mJDk49xZFIlKxkunVL7xtIFyOPTN/category_gameplay/flatDark41.png","frameSize":{"x":108,"y":48},"frameCount":1,"looping":true,"frameDelay":2,"version":"3Tm5mJDk49xZFIlKxkunVL7xtIFyOPTN","loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":48},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3Tm5mJDk49xZFIlKxkunVL7xtIFyOPTN/category_gameplay/flatDark41.png"},"0076ca5f-aefc-4e0e-9a91-67bd02abb62d":{"name":"menu","sourceUrl":null,"frameSize":{"x":108,"y":48},"frameCount":1,"looping":true,"frameDelay":12,"version":"cx5xtkTzZgbxdgHtp0l3IDQ3bdv.jO6h","loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":48},"rootRelativePath":"assets/0076ca5f-aefc-4e0e-9a91-67bd02abb62d.png"},"f9e460b4-89eb-4a0a-9881-72b906d15a5a":{"name":"spring_2","sourceUrl":null,"frameSize":{"x":145,"y":77},"frameCount":1,"looping":true,"frameDelay":12,"version":"6QPbSLX4ERiAAzw.kkTf3Y6O8rg4BwCr","loadedFromSource":true,"saved":true,"sourceSize":{"x":145,"y":77},"rootRelativePath":"assets/f9e460b4-89eb-4a0a-9881-72b906d15a5a.png"},"200fcaf8-c55b-4ca3-bdec-a2e5afa814e7":{"name":"iron man","sourceUrl":null,"frameSize":{"x":136,"y":136},"frameCount":3,"looping":true,"frameDelay":4,"version":"CxglMLES.t.XaEjwwC.LZAnP_tpfbmC5","loadedFromSource":true,"saved":true,"sourceSize":{"x":272,"y":272},"rootRelativePath":"assets/200fcaf8-c55b-4ca3-bdec-a2e5afa814e7.png"},"be051262-d38e-4ec8-b0ac-5048d160c5dc":{"name":"iron man_","sourceUrl":null,"frameSize":{"x":136,"y":136},"frameCount":1,"looping":true,"frameDelay":12,"version":"A0evzwadXyUIY5rQqH9gyFIHQ.hV4AAS","loadedFromSource":true,"saved":true,"sourceSize":{"x":136,"y":136},"rootRelativePath":"assets/be051262-d38e-4ec8-b0ac-5048d160c5dc.png"},"3b84c9b0-9798-4f36-ba42-21e363e4bd0a":{"name":"spiderMan","sourceUrl":"assets/v3/animations/1VGDHl4AykJLX94qQOws4T1wgaXNN4CjpIhdG1PHMs8/3b84c9b0-9798-4f36-ba42-21e363e4bd0a.png","frameSize":{"x":100,"y":98},"frameCount":1,"looping":true,"frameDelay":4,"version":"dRovnbL0fJWaa92uKDhVG1vVNNTo4rWt","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":98},"rootRelativePath":"assets/v3/animations/1VGDHl4AykJLX94qQOws4T1wgaXNN4CjpIhdG1PHMs8/3b84c9b0-9798-4f36-ba42-21e363e4bd0a.png"},"0d5464ce-d933-46c4-aed2-657b4d1dbf1a":{"name":"bg","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"QLahw0mvFD401Hsu6ATmUer6ngmFMUoL","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/0d5464ce-d933-46c4-aed2-657b4d1dbf1a.png"},"fb01deab-2e69-461e-a2b2-0376c722badf":{"name":"hulk1.png_1","sourceUrl":null,"frameSize":{"x":310,"y":227},"frameCount":18,"looping":true,"frameDelay":5,"version":"PbGW5kE5SxNfKMhKVy4cFIvcllHSg8RI","loadedFromSource":true,"saved":true,"sourceSize":{"x":1240,"y":1135},"rootRelativePath":"assets/fb01deab-2e69-461e-a2b2-0376c722badf.png"},"9710c498-868c-4e1c-bb19-a4aeadd84930":{"name":"choose.jpg_1","sourceUrl":null,"frameSize":{"x":410,"y":223},"frameCount":1,"looping":true,"frameDelay":12,"version":"0YOnvGVXo022GIkCTe3lTUii9D.MMSd7","loadedFromSource":true,"saved":true,"sourceSize":{"x":410,"y":223},"rootRelativePath":"assets/9710c498-868c-4e1c-bb19-a4aeadd84930.png"},"289f17ca-c3c0-4482-b150-1672c9a43644":{"name":"goodEvil.jpg_1","sourceUrl":null,"frameSize":{"x":410,"y":223},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZoelNYwdZ.3wdC4NGMrg3QsAPcD7Tipr","loadedFromSource":true,"saved":true,"sourceSize":{"x":410,"y":223},"rootRelativePath":"assets/289f17ca-c3c0-4482-b150-1672c9a43644.png"},"51109ae5-9a8a-4ca9-bf60-4bf18af27e1e":{"name":"city_1.jpg_1","sourceUrl":null,"frameSize":{"x":662,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"v7pAHGmFFvyX8dZC6EZIvrg3wJgh8qYZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":662,"y":400},"rootRelativePath":"assets/51109ae5-9a8a-4ca9-bf60-4bf18af27e1e.png"},"43b626de-e5d4-417d-ba27-0f25c905530c":{"name":"hand.jpg_1","sourceUrl":null,"frameSize":{"x":420,"y":420},"frameCount":1,"looping":true,"frameDelay":12,"version":"l9S64PHUl.v.M0RCrCakNys8AR3xthdh","loadedFromSource":true,"saved":true,"sourceSize":{"x":420,"y":420},"rootRelativePath":"assets/43b626de-e5d4-417d-ba27-0f25c905530c.png"},"2112346e-2580-4e0c-8472-ab0ff8acf246":{"name":"diamond.png_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"7d826Tae.LN1d2dH8scjwRQzCNGFYNXS","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/2112346e-2580-4e0c-8472-ab0ff8acf246.png"},"8e4ccc0b-3540-4b96-a012-db26f30a1300":{"name":"diamond.png_1_copy_1","sourceUrl":null,"frameSize":{"x":50,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"Mk0UNe6xXKDXQSIEDd.eiugfcLjn18U9","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":50},"rootRelativePath":"assets/8e4ccc0b-3540-4b96-a012-db26f30a1300.png"},"92d806d5-bd31-4f9c-9b6c-030766b0b886":{"name":"thanos","sourceUrl":null,"frameSize":{"x":101,"y":119},"frameCount":10,"looping":true,"frameDelay":12,"version":"FheNFoRDKKRsDbtTPb0l.YKLzeaEXQ0N","loadedFromSource":true,"saved":true,"sourceSize":{"x":303,"y":476},"rootRelativePath":"assets/92d806d5-bd31-4f9c-9b6c-030766b0b886.png"},"4c96ead6-93d6-4ddc-b3bb-3828aba59e4c":{"name":"thon","sourceUrl":null,"frameSize":{"x":101,"y":116},"frameCount":1,"looping":true,"frameDelay":12,"version":"O34u5Tzz4ZGVJGBk2VktmUMdSpEQ1Nd3","loadedFromSource":true,"saved":true,"sourceSize":{"x":101,"y":116},"rootRelativePath":"assets/4c96ead6-93d6-4ddc-b3bb-3828aba59e4c.png"},"de495cfd-653e-4801-850e-ab037ca60e23":{"name":"LOGO","sourceUrl":null,"frameSize":{"x":400,"y":397},"frameCount":1,"looping":true,"frameDelay":12,"version":"SZ6qB6lDVqohcvJj69D4ikgGL7pHqdgq","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":397},"rootRelativePath":"assets/de495cfd-653e-4801-850e-ab037ca60e23.png"},"3601afcf-9a96-47f2-a95e-ef66d0064cbd":{"name":"?","sourceUrl":null,"frameSize":{"x":100,"y":92},"frameCount":1,"looping":true,"frameDelay":12,"version":"mcBreWIDBrdmCMRfqi0Q6c7DIiSsbara","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":92},"rootRelativePath":"assets/3601afcf-9a96-47f2-a95e-ef66d0064cbd.png"},"17da732d-c1a6-4efa-a291-8fb20f9c53df":{"name":"day","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"R7PTKexCHgRoqZAO00105kA1tkJrM1rO","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/17da732d-c1a6-4efa-a291-8fb20f9c53df.png"},"87331e83-0313-425c-bba3-0998395f9a2a":{"name":"Icon.png_1","sourceUrl":"assets/v3/animations/aOooRnqmMmOUDIpkmchKmaMgVcs9UN7Fu15veOtktdE/87331e83-0313-425c-bba3-0998395f9a2a.png","frameSize":{"x":300,"y":300},"frameCount":1,"looping":true,"frameDelay":4,"version":"G2trhanCQsj8Y8nuAD8IISxhhr4QPIby","loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":300},"rootRelativePath":"assets/v3/animations/aOooRnqmMmOUDIpkmchKmaMgVcs9UN7Fu15veOtktdE/87331e83-0313-425c-bba3-0998395f9a2a.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


//GAMESTATE
var menu = 2;
var START = 1;
var cha = 7;
var SERVE = 3;
var INFO = 4;
var INFO2 = 5;
var PLAY = 6;
var END =0;
var gameState = START;

var bg = createSprite(200,200,400,400);
bg.setAnimation("city_1.jpg_1");
bg.scale = 1.2;
bg.velocityX = -0.01;
bg.x=bg.width/2;


var bg2 = createSprite(100,80,400,400);
bg2.setAnimation("animation_1");
bg2.scale = 2;

//group
var enemyGroup = createGroup();
var goldGroup = createGroup();
var silverGroup = createGroup();
var bronceGroup = createGroup();
var springGroup = createGroup();
var hulkGroup = createGroup();
var scoreDisplay = createGroup();
var info = createGroup();
var menu1 = createGroup();
var spider = createGroup();
var iron =createGroup();
var thanos = createGroup();
var diaGroup = createGroup();

//player
var player = createSprite(100,340,20,50);
player.setAnimation("Spiderman");
player.scale=0.5;


//ground
var ground = createSprite(200,385,400,20);
ground.x = ground.width /2;
ground.shapeColor="green";

//invisibleLine
var line2 =createSprite(200,375,400,2);
line2.shapeColor="red";
line2.visible=false;

   




//time
var time = 0 ;
var gold=0;
var silver=0;
var bronce=0;
var total = 0;
var life = 0;
var diamond = 0;

var shake = 0;

function draw() {
  
    background("white");
    player.collide(ground);
    
    time = Math.round(time+1);
      
   textSize(30);
   textFont("georgia");
     
     if(bg.x<0){
       bg.x = 200;
     } 
     
  
   
   if(gameState===PLAY){ 
      playSound("assets/category_background/synthesize.mp3",false);
      stopSound("assets/category_background/synthesize.mp3");
      
      iron.setVisibleEach(false);
      spider.setVisibleEach(false);
      info.setVisibleEach(false);
      menu1.setVisibleEach(false);
      scoreDisplay.setVisibleEach(false);
      player.visible=true;
      thanos.setVisibleEach(false);

      if(keyDown("space")&&player.isTouching(line2)){
         player.velocityY = -18 ;
         bg.velocityX=-6;
         playSound("assets/category_jump/jump_7.mp3");
         

      }
      
      else{
        player.velocityY = player.velocityY + 0.8;
        bg.velocityX = -3;
      }
      
      
      
     
          
      if (goldGroup.isTouching(player)) {
          goldGroup.destroyEach();
          gold=gold+5;
          total = total+5;
          playSound("assets/category_achievements/lighthearted_bonus_objective_3.mp3")
             
      } 
        
        
      if (silverGroup.isTouching(player)) {
          silverGroup.destroyEach();
          silver=silver+3;
          total = total+3;
      } 
                
      if (bronceGroup.isTouching(player)) {
          bronceGroup.destroyEach();
          bronce = bronce+2;
          total = total+2;
      } 
           
           
      
              
      if(springGroup.isTouching(player)){
          springGroup.setAnimationEach("spring_in_out_1");
          player.velocityY = -20;
      }    
        
         
      if(diaGroup.isTouching(player)){
        diaGroup.destroyEach();
        diamond = diamond+1;
      }   
      
           
      if(hulkGroup.isTouching(player)){
          gameState = END;
      }
    
           
           
      
      green ();
      gold1  ();
      bronce1();
      silver1();
      spring();
      blue();

    }
    
    if (shake>0) {
      background(rgb(255, 0, 0, shake/100));
      camera.x = randomNumber(190, 202);
      camera.y = randomNumber(190, 202);
      shake--;
    }
    
   
    if(gameState===END){
        
     
       /*var score = createSprite(200,200,50,3);
       score.setAnimation("Spiderman");
       
       scoreDisplay.add(score);
       */
       
       var ba = createSprite(195,200,400,400);
       ba.setAnimation("hand.jpg_1");
       ba.lifetime = 50;
       info.add(ba);
       
       ground.velocityX=0;
       player.visible = false;
       player.x=100;
       enemyGroup.setLifetimeEach=-1;        
       enemyGroup.velocityX=0;
       shake = 0;
       
       var home = createSprite(350,50,50,50);
       home.setAnimation("menu");
       home.scale=0.5;
       menu1.add(home);
       
       if(mousePressedOver(home)){
         gameState=menu;
       }
       
     
       if(keyDown("r")){
          gameState = PLAY;
          player.visible = true ;
         
          player.y = 340;
          gold=0;
          silver=0;
          bronce=0;
          total = 0;
          player.scale = 0.5;

        } 
        
     }
      
   
   drawSprites();
      
   if(gameState===PLAY){ 
       text("SCORE ="+total,20,50);
       text ("DIAMOND = "+diamond,200,50);
   }
   
   if(gameState===menu){
     
     total =0;
     bronce = 0;
     silver = 0;
     gold = 0;
     
     var good = createSprite(200,100,250,260);
     good.setAnimation("goodEvil.jpg_1");
    
     info.add(good);
    
     player.x =100;
     player.y= 340;
     
      
    
     
     var choose = createSprite(200,300,230,200);
     choose.setAnimation("choose.jpg_1");
     choose.scale=1.03;
     info.add(choose);
     
     /*var question = createSprite(40,50,500,50);
     question.setAnimation("?");
     question.scale = 0.5;
     question.depth = question.depth+5;
     info.add(question);*/
     
     var Diamond = createSprite(350,350,50,50);
     Diamond.setAnimation("diamond.png_1_copy_1");
     info.add(Diamond);
     
     /*if(mousePressedOver(question)){
       gameState = SERVE;
   }*/
     
     
     if(mouseIsOver(Diamond)){
       fill("white");
       background("lightblue");
       text("no of DIAMOND = "+ diamond,20,40);
     }
     
     if(mousePressedOver(choose)){
        gameState=cha;
     }
     
    }
   
   
   
   if(gameState === SERVE){
      fill("White");
      background("red");
      textSize(25);

      text("THE HULK IS ", 20,280);
      text("THE ENEMY",20,320);
      text("PRESS e TO EXIT THE PAGE",20,360);
      text("Press"+" "+ "a"+" "+ "to"+" "+ "move to next page",20,390);
       
      if(keyDown("a")){
         gameState = INFO;
      }
      
       if(keyDown("e")){
         gameState = menu;
      
      }
    }
   
   if(gameState===INFO){
       fill("White");
       background("red");
       textSize(25);
       text("PRESS SPACE TO JUMP",25,40);
       text("THERE ARE GOLD,SILVER",20,80);
       text("AND BRONZE COINS.",20,120);
       text("COLLECT THEM TO",20,160);
       text("SCORE POINTS ",20,200);
       text("ALL THE BEST SCORE WELL !!!!",20,240);
       text("PRESS e TO EXIT THE PAGE",20,300);
       text("PRESS b TO MOVE TO ",20,340);
       text("NEXT PAGE",20,380);
       
       if(keyDown("b")){
          gameState = INFO2;
        }
      
       if(keyDown("e")){
         gameState = menu;
         
        }
      
     }
     
   
   
   if(gameState===INFO2){
     
       fill("White");
       background("red");
       textSize(25);
       text("NOTE  :",25,40);
       text("THE BLACK SPIDERMAN",20,80);
       text("WILL BE HIDDEN",20,120);
       text("BEHIND COINS or ",20,160);
       text("ENERGY DRINK",20,200);
       text("or POISEN",20,240);
       text("SO BE CAREFULL",20,280);
       text("PRESS r TO RETURN TO HOME  ",20,380);
       
      if(keyDown("r")){
        gameState = menu;
      }
    
    } 
   
   
   if(gameState === cha){
     
       var bg5 = createSprite(200,200,400,400);
       bg5.setAnimation("bg");
       info.add(bg5);

       
       var spider1 = createSprite(70,150,50,50);
       spider1.setAnimation("spiderMan");
       spider.add(spider1);
       
       var iron1 = createSprite(70,300,50,50);
       iron1.setAnimation("iron man_");
       iron.add(iron1);
       
       var t = createSprite(300,200,50,50);
       t.setAnimation("thon");
       t.scale = 1;
       thanos.add(t);
       
       if(mousePressedOver(spider1)){
         player.setAnimation("Spiderman");
         gameState=PLAY;
         
       }
       
       
       
     if (mousePressedOver(iron1)&& diamond>=30) {
       player.setAnimation("iron man");
       gameState = PLAY;
       diamond = diamond-30;
     } else {
       
       if(mouseIsOver(iron1)&& diamond < 30){
           text("YOU NEED 30 DIAMOND \n TO  UNLOCK  IRON MAN ",20,40);
           
         }
     }
       
      
        
       if(mousePressedOver(t)&& diamond>= 100){
         player.setAnimation("thanos");
         gameState = PLAY;
         player.scale = 0.5;
         
       }
       
       
       if(mouseIsOver(t)&& diamond < 100){
           text("YOU NEED 100 DIAMOND TO \n UNLOCK  THANOS  ",20,40);
           
         }
     }
       
   if(gameState===START){
     var Bg = createSprite(200,200,400,400);
     Bg.setAnimation("LOGO");
     Bg.lifetime = 50;
    // playSound("assets/category_background/eerie_beginnings.mp3",false)
     
     if(time === 80 ||time>80){
       Bg.destroy();
       gameState = menu;
     }
   }
  
    if(gameState===END){
      // stopSound("assets/category_background/eerie_beginnings.mp3")
    //    stopSound("assets/category_background/outback.mp3");
        stopSound("assets/category_background/synthesize.mp3");

        text("GAME OVER",200,30);
        textSize(30);
        textFont("georgia");
        text (" PRESS R TO PLAY AGAIN",20,390);
    }   
    
}

     


function gold1 (){
  
  if(World.frameCount%300===0){
    var coin1 = createSprite(400,100,0,0);
    coin1.setAnimation("coin_gold_1");
    coin1.scale=0.5;
    coin1.y = randomNumber(200,350);
    coin1.velocityX=-10;
    coin1.lifetime=100;
    goldGroup.add(coin1);
    
   
      
     
  }
}


function silver1 (){
  
  if(World.frameCount%200===0){
    var silver = createSprite(400,100,0,0);
    silver.setAnimation("coin_silver_1");
    silver.scale=0.5;
    silver.y = randomNumber(200,350);
    silver.velocityX=-10;
    silver.lifetime=100;
    silverGroup.add(silver);
    

     
    }
       
  }



function bronce1 (){
  
  if(World.frameCount%100===0){
    var bronce = createSprite(400,100,0,0);
    bronce.setAnimation("coin_bronze_1");
    bronce.scale=0.5;
    bronce.y = randomNumber(200,350);
    bronce.velocityX=-10;
    bronce.lifetime=100;
    bronceGroup.add(bronce);
    

      }
    }

function spring (){
   
  if(World.frameCount%300===0){
    
    var jump = createSprite(400,370,20,50);
    jump.setAnimation("spring_1");
    jump.scale=0.5;
    jump.lifetime=200;
    jump.velocityX = -10;
    springGroup.add(jump);
    

      
    }
      
  
}

function green (){
   
  if(World.frameCount% 500===0){
    
    var hulk = createSprite(400,325,20,50);
    hulk.setAnimation("hulk1.png_1");
    hulk.scale=0.5;     
    hulk.lifetime=200;
    hulk.velocityX = -10;
    hulkGroup.add(hulk);
    
    hulk.setCollider("circle",0,10,100);
    
    shake = 50;
    
    
    }
      
  
}


function blue (){
   
  if(World.frameCount%100===0){
    
    var shine = createSprite(400,325,20,50);
    shine.setAnimation("diamond.png_1");
    shine.scale=0.5;     
    shine.lifetime=200;
    shine.velocityX = -10;
    diaGroup.add(shine);
    
    shine.setCollider("circle",0,10,100);
    
    
    }
      
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
